$(function (){
    $(".existing").hide();
    $(".hidden_item1").hide();
    $(".hidden_item2").hide();

});